FONT BY DENISE BENTULAN (c) 2013
http://deathmunkey.deviantart.com
http://www.dafont.com/denise-bentulan.d2156
http://douxiegirl.com

-----------------------------------------------------------------------------------------

Free for personal use ONLY.
For commercial use, please email the designer at dnn.bntln@yahoo.com or contact@douxiegirl.com

-----------------------------------------------------------------------------------------

PayPal donations are highly appreciated!
these help me in a way through college.
you may send them to my PayPal account, dnn.bntln@yahoo.com.

thank you.

-----------------------------------------------------------------------------------------